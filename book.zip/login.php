<?php
$page_title = 'Login';
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email)) $errors[] = 'Email is required.';
    if (empty($password)) $errors[] = 'Password is required.';

    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT u.*, r.role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Check email verification (skip for admin)
                if (!$user['is_verified'] && $user['role_name'] !== 'admin') {
                    // Check if there's still a valid OTP
                    if (empty($user['otp_code']) || strtotime($user['otp_expiry']) < time()) {
                        sendOtpEmail($conn, $email);
                    }
                    $_SESSION['otp_email'] = $email;
                    redirect("verify_otp.php?email=" . urlencode($email), 'Please verify your email before logging in.', 'warning');
                }
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role_name'];
                $_SESSION['profile_pic'] = $user['profile_pic'];
                $_SESSION['is_verified'] = $user['is_verified'];

                if ($user['role_name'] === 'admin') {
                    redirect('admin/dashboard.php', 'Welcome back, Admin!', 'success');
                } else {
                    redirect('index.php', 'Login successful! Welcome back.', 'success');
                }
            } else {
                $errors[] = 'Invalid email or password.';
            }
        } else {
            $errors[] = 'Invalid email or password.';
        }
    }
}

require_once 'includes/header.php';
?>

<div class="row justify-content-center mt-5">
    <div class="col-md-5">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <i class="bi bi-book-fill fs-1 text-primary"></i>
                    <h4 class="fw-bold mt-2">Welcome Back</h4>
                    <p class="text-muted">Sign in to continue to BookStore</p>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo h($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-lock"></i></span>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between mb-3">
                        <a href="forgot_password.php" class="text-decoration-none small">Forgot Password?</a>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2">Sign In</button>
                </form>

                <p class="text-center mt-3 mb-0">
                    Don't have an account? <a href="register.php" class="text-decoration-none">Register</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
