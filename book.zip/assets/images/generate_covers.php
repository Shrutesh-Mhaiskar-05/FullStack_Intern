<?php
$books = [
    ['file' => '9780743273565.jpg',  'title' => 'The Great Gatsby',       'color' => [0x0d, 0x6e, 0xfd]],
    ['file' => '9780061120084.jpg',  'title' => 'To Kill a Mockingbird',  'color' => [0x19, 0x84, 0x54]],
    ['file' => '9780452284234.jpg',  'title' => '1984',                   'color' => [0xdc, 0x35, 0x45]],
    ['file' => '9780553380163.jpg',  'title' => 'A Brief History of Time','color' => [0x6f, 0x42, 0xc1]],
    ['file' => '9780062316097.jpg',  'title' => 'Sapiens',                'color' => [0xe7, 0x4c, 0x3c]],
    ['file' => '9780547928227.jpg',  'title' => 'The Hobbit',             'color' => [0x1a, 0xb7, 0x6d]],
    ['file' => '9781451648539.jpg',  'title' => 'Steve Jobs',             'color' => [0x2c, 0x3e, 0x50]],
    ['file' => '9781590302259.jpg',  'title' => 'The Art of War',         'color' => [0x8e, 0x44, 0xad]],
    ['file' => 'default-book.png',   'title' => 'Book',                   'color' => [0x0d, 0x6e, 0xfd]],
    ['file' => 'default.png',        'title' => 'User',                   'color' => [0x6c, 0x75, 0x7d]],
];

function createImage($filename, $title, $bgColor, $width = 200, $height = 280) {
    $image = imagecreatetruecolor($width, $height);
    $bg = imagecolorallocate($image, $bgColor[0], $bgColor[1], $bgColor[2]);
    $white = imagecolorallocate($image, 255, 255, 255);
    $light = imagecolorallocate($image, 255, 255, 255);

    imagefill($image, 0, 0, $bg);

    $cx = $width / 2;
    $cy = $height / 2;

    $bookW = 80;
    $bookH = 100;
    $bx = ($width - $bookW) / 2;
    $by = ($height - $bookH) / 2 - 20;

    imagefilledrectangle($image, $bx, $by, $bx + $bookW, $by + $bookH, $light);
    imagefilledrectangle($image, $bx + 3, $by + 3, $bx + $bookW - 3, $by + $bookH - 3, $bg);
    $spineX = $bx + intval($bookW * 0.18);
    imageline($image, $spineX, $by + 3, $spineX, $by + $bookH - 3, $light);
    $pagesX = $spineX + 2;
    for ($i = 0; $i < 4; $i++) {
        imageline($image, $pagesX + $i * 2, $by + 5, $pagesX + $i * 2, $by + $bookH - 5, $light);
    }

    $text = $title;
    $fontSize = 3;
    $tw = imagefontwidth($fontSize) * strlen($text);
    $tx = ($width - $tw) / 2;
    $ty = $by + $bookH + 25;
    imagestring($image, $fontSize, $tx, $ty, $text, $white);

    $subText = 'Online Bookstore';
    $fontSize2 = 2;
    $tw2 = imagefontwidth($fontSize2) * strlen($subText);
    $tx2 = ($width - $tw2) / 2;
    $ty2 = $ty + 20;
    imagestring($image, $fontSize2, $tx2, $ty2, $subText, $light);

    imagepng($image, $filename);
    imagedestroy($image);
}

$dir = __DIR__;
foreach ($books as $book) {
    $path = $dir . DIRECTORY_SEPARATOR . $book['file'];
    createImage($path, $book['title'], $book['color']);
    echo "Created: " . $book['file'] . "\n";
}
echo "\nAll cover images generated successfully!";
